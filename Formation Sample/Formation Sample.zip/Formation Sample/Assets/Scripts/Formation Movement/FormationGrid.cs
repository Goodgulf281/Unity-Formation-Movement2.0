﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// DEPRECATED


namespace Goodgulf.Formation
{
    public class FormationGrid
    {
        
        /*
        public List<FormationGridPoint> formationGridPoints = new List<FormationGridPoint>();

        public void AddFormationGridPoint(FormationLeader leader, Vector2 offset, LayerMask layerMask, FormationFollower follower)
        {
            if (offset.y > 0)
            {
                Debug.LogError("FormationGrid.AddFormationGridPoint(): Offset Y coordinate should always be < 0." + offset.y);
            }
            else
            {
                FormationGridPoint formationGridPoint = new FormationGridPoint(leader, offset, layerMask, follower);
                formationGridPoints.Add(formationGridPoint);
            }
        }

        public void UpdateFormationPositions(Transform leaderTransform)
        {
            

            foreach(FormationGridPoint formationGridPoint in formationGridPoints)
            {

                formationGridPoint.RecalculatePosition(leaderTransform);

            }


        }

        */

    }
}